import { CliLogLevel } from "./types";
export declare function createDeenruvApp(name: string | undefined, useNpm: boolean, logLevel: CliLogLevel, isCi?: boolean): Promise<void>;
